subplot(2,2,1);
x=-10:0.05:10;
y = x.^2;
plot(x,y)

subplot(2,2,2);
y1 = sin(x);
plot(x,y1)

subplot(2,2,3);  
y2 = 3*x + 5;
plot(x,y2)

subplot(2,2,4);
y3 = sin(3*x);
plot(x,y3,'--r')
title('Sinewave')
xlabel('x')
ylabel('y')
