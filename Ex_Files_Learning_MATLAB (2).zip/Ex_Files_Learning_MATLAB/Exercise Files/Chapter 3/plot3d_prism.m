% This is a 3D plot of a triangular prism using patch command

patch([0,6,3],[0,0,4],[0,0,0],'r') % bottom base red color
patch([0,6,3], [0,0,4], [5,5,5], 'y')    % top base yellow color
patch([0,3,3,0], [0,4,4,0], [0,0,5,5], 'g')   % left face green color
patch([0,6,6,0], [0,0,0,0], [0,0,5,5], 'b')   % front face blue color
patch([6,3,3,6], [0,4,4,0], [0,0,5,5], 'm')   % right face magenta color



