% This is a 3D plot of a pyramid

x = 0:6;
y = 0:4;
z = 0:4;

patch([0,6,3],[0,0,4],[0,0,0],'m')   % bottom base magenta color
patch([0,6,3],[0,0,4],[0,0,4],'g')   % front face green color
patch([0,3,3],[0,4,4],[0,0,4],'r')   % left face red color
patch([6,3,3],[0,4,4],[0,0,4],'y')   % right face yellow color

title('This is a 3D plot of a pyramid')
xlabel('X')
ylabel('Y')
zlabel('Z')
