function [y] = myline(x)
% This is a linear function

y = 2*x + 3;

end