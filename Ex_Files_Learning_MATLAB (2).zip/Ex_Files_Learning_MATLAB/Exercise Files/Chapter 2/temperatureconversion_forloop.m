% Temperature conversion

for tc=0:2:10
    tf=(tc*1.8 + 32);
    disp(tf)
end