% Is it going to be cold or hot today?

Tref=20;
T=50;
if T>Tref
    c="It's going to be hot today"
elseif T==Tref
    c="It's going to be cool today"
else 
    c="It's going to be cold today"
end
