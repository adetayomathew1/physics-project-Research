% Calculate number of students failing and passing

Grades = [40 55 90 83 62 30 50 100 70 45 67 53 86 83 42 30 60 97 72 47];
n = 0;
m = 0;

for i = 1:1:20
    if Grades(i) < 50
        n = n + 1;
    else
        m = m + 1;
    end
end
failtext = "Number of students failing is " + n
passtext = "Number of students passing is " + m


