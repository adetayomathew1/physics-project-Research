% The for loop/ Power function

for x=1:1:4
    y=x^3;
    disp(y)
end
