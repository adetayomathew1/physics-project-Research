% The while loop example

x = 2;
while x<30
    x=2*x^2+1
end
disp('x is higher than 30')