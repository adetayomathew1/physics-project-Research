% Calculate area and perimeter of a rectangle

L = 5;
W = 10;
A = L*W;
P = 2*L + 2*W;