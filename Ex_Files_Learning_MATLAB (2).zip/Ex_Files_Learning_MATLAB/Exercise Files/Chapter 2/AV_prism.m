function [A,V] = AV_prism(h,b,H)
%Calculate the area of the triangular prism

A = h*b/2;
V = A*H;
end