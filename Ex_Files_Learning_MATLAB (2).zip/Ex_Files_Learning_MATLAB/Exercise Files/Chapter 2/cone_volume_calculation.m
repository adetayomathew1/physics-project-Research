function [V] = cone_volume_calculation(r,h)
% This function is used to calculate the volume of a cone.

V = pi*r^2*h/3;

end