% Calculate hypotenuse of a right triangle when you know two sides

A1=10;
A2=10;
C=A1^2 + A2^2;
H = sqrt(C);
